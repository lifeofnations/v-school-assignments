I created a text based RPG game. I went well abobe the xpected requirements on this one and added stats
and random stat generation. also added to hit chances because auto hitting is no fun :P
